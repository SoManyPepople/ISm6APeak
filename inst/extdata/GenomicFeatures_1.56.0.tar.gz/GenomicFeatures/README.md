[<img src="https://www.bioconductor.org/images/logo/jpg/bioconductor_logo_rgb.jpg" width="200" align="right"/>](https://bioconductor.org/)

**GenomicFeatures** is an R/Bioconductor package for conveniently importing and querying gene models in R.

See https://bioconductor.org/packages/GenomicFeatures for more information including how to install the release version of the package (please refrain from installing directly from GitHub).

