### =========================================================================
### makeTxDbFromGRanges()
### -------------------------------------------------------------------------

### Everything in this file has moved to txdbmaker!

makeTxDbFromGRanges <- function(...)
{
    call_fun_in_txdbmaker("makeTxDbFromGRanges", ...)
}

