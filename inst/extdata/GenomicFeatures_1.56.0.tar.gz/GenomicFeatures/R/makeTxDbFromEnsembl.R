### =========================================================================
### makeTxDbFromEnsembl()
### -------------------------------------------------------------------------

### Everything in this file has moved to txdbmaker!

makeTxDbFromEnsembl <- function(...)
{
    call_fun_in_txdbmaker("makeTxDbFromEnsembl", ...)
}

