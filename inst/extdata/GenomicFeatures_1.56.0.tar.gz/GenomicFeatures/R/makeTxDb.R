### =========================================================================
### Making TxDb objects
### -------------------------------------------------------------------------

### Everything in this file has moved to txdbmaker!

makeTxDb <- function(...)
{
    call_fun_in_txdbmaker("makeTxDb", ...)
}

