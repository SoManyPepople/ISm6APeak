### =========================================================================
### makeTxDbFromBiomart()
### -------------------------------------------------------------------------

### Everything in this file has moved to txdbmaker!

getChromInfoFromBiomart <- function(...)
{
    call_fun_in_txdbmaker("getChromInfoFromBiomart", ...)
}


makeTxDbFromBiomart <- function(...)
{
    call_fun_in_txdbmaker("makeTxDbFromBiomart", ...)
}

